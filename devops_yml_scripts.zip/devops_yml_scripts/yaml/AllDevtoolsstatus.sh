nvm --version
node --version
git --version
openssl --version
docker --version
./usr/local/bin/docker-compose --version
